//
//  Constants.swift
//  SampleApp
//
//  Created by John Raja on 22/05/19.
//  Copyright © 2019 John Raja. All rights reserved.
//

import Foundation

struct Constants {
    
    struct API {
        static let URL = "http://perfectrdp.us/newspaper_webservice"
        
        //static let URL = "http://friendservice.herokuapp.com"
        
    }
}
